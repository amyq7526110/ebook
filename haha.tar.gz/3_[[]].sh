#!/bin/bash


#  test 表达式放在[[]]中.(shell 关键字)
#       具体查看[[]]结构的讨论.



