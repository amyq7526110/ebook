#!/bin/bash


#   \<,\>

#         正则中的单词边界


     echo   "haha the thee"  > tesfile

     grep '\<the\>'  tesfile
