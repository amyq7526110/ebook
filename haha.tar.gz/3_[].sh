#!/bin/bash

#   []  test 

#       test 的 表达式 放在 []中

#       值得注意的是[是 shell 内建 test 命令的一部分,并不是/usr/bin/test 中的扩展命令的一个连接.   

#       数组元素
  
        Array[1]=slot_1

        echo  ${Array[1]}


#       字符范围

#       在正则表达式中使用，作为字符匹配的一个范围


 




