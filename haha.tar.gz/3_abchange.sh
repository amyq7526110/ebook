#!/bin/bash


#    uppercase.sh : 修改输出，全部转换成为大写


    tr 'a-z'  'A-Z' 


#   字符范围必须被引用起来

#+  来阻止产生单字符的文件名

exit 0


  

