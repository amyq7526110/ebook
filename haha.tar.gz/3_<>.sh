#!/bin/bash


#   ASCLL 比较

    veg1=a

    veg2=b


    if [[  "$veg1"  <  "$veg2"    ]]

    then

        echo "Although $veg1 precede $veg2 in the dictionary."

	echo "this implies  nothing about my culinary preferences."

    else 

        echo  "What kind of dictionary are you using.anyhow."

    fi	

